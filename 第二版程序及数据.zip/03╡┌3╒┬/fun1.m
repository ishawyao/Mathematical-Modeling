function f=fun1(x);
f=sum(x.^2)+8;
