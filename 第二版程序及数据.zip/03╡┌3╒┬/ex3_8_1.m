syms x y
[x,y]=solve(x^2+y-6,y^2+x-6)
