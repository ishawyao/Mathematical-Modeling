syms x
I=int(1/(1+sqrt(1-x^2)))
pretty(I)
